from django.shortcuts import render,redirect

# Create your views here.
def home(request,id):
    data = [
        {"name":"BELL PEPPER","img":"assets/images/product-1.jpg"},
        {"name":"STRAWBERRY","img":"assets/images/product-2.jpg"},
        {"name":"BEANS","img":"assets/images/product-3.jpg"},
        {"name":"PURPLE CABBAGE","img":"assets/images/product-4.jpg"},
        {"name":"TOMATO","img":"assets/images/product-5.jpg"},
        ]
    
    return render(request,'home.html',{'product':data})

def product(request):
    return render(request,'product.html')


def single_product(request,id):
    return render(request,'single-product.html')